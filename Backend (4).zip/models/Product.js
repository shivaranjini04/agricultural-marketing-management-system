const mongoose = require('mongoose');

const productSchema = mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    image: {
      type: String,
    },
    category: {
      type: String,
      required: true,
      enum: ['vegetables', 'fruits', 'grains', 'dairy', 'herbs'],
    },
    price: {
      type: Number,
      required: true,
      default: 0,
    },
    quantity: {
      type: Number,
      required: true,
      default: 0,
    },
    isOrganic: {
      type: Boolean,
      default: false,
    },
    expiryDate: {
      type: Date,
      required: true,
    },
    status: {
      type: String,
      enum: ['active', 'sold-out', 'expired'],
      default: 'active',
    },
  },
  {
    timestamps: true,
  }
);

// Calculate status based on quantity and expiry date
productSchema.pre('save', function(next) {
  const today = new Date();
  
  if (this.quantity <= 0) {
    this.status = 'sold-out';
  } else if (this.expiryDate < today) {
    this.status = 'expired';
  } else {
    this.status = 'active';
  }
  
  next();
});

const Product = mongoose.model('Product', productSchema);

module.exports = Product;