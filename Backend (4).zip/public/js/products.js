document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const productsContainer = document.getElementById('products-container');
    const productModal = document.getElementById('product-modal');
    const confirmModal = document.getElementById('confirm-modal');
    const productForm = document.getElementById('product-form');
    const modalTitle = document.getElementById('modal-title');
    const productSearch = document.getElementById('product-search');
    const categoryFilter = document.getElementById('category-filter');
    const statusFilter = document.getElementById('status-filter');
    
    // Modal elements
    const addProductBtn = document.getElementById('add-product-btn');
    const closeBtn = document.querySelector('.close');
    const cancelBtn = document.getElementById('cancel-btn');
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    const cancelDeleteBtn = document.getElementById('cancel-delete');
    
    // Form elements
    const productIdInput = document.getElementById('product-id');
    const productNameInput = document.getElementById('product-name');
    const productDescInput = document.getElementById('product-description');
    const productCategoryInput = document.getElementById('product-category');
    const productQuantityInput = document.getElementById('product-quantity');
    const productPriceInput = document.getElementById('product-price');
    const productExpiryInput = document.getElementById('product-expiry');
    const organicCheckInput = document.getElementById('organic-check');
    const productImageInput = document.getElementById('product-image');
    const imagePreview = document.getElementById('image-preview');
    
    let products = [];
    let currentProductId = null;
    
    // Fetch all products
    async function fetchProducts() {
        try {
            const response = await fetch('/api/products');
            const data = await response.json();
            products = data;
            renderProducts();
        } catch (error) {
            showNotification('Error loading products', 'error');
        }
    }
    
    // Render products to the DOM
    function renderProducts() {
        let filteredProducts = filterProducts();
        
        if (filteredProducts.length === 0) {
            productsContainer.innerHTML = `
                <div class="no-products">
                    <i class="fas fa-seedling"></i>
                    <h3>No products found</h3>
                    <p>Add your first agricultural product to start selling</p>
                </div>
            `;
            return;
        }
        
        let productsHTML = '';
        
        filteredProducts.forEach(product => {
            productsHTML += `
                <div class="product-card">
                    <div class="product-status ${product.status}">${product.status}</div>
                    <div class="product-image">
                        ${product.image 
                            ? `<img src="${product.image}" alt="${product.name}">`
                            : `<div class="no-image"><i class="fas fa-image"></i></div>`
                        }
                        ${product.isOrganic ? '<div class="organic-badge">Organic</div>' : ''}
                    </div>
                    <div class="product-info">
                        <h3>${product.name}</h3>
                        <div class="product-category">${product.category}</div>
                        <div class="product-price">$${product.price.toFixed(2)} / kg</div>
                        <div class="product-quantity">Available: ${product.quantity} kg</div>
                        <div class="product-expiry">Expires: ${new Date(product.expiryDate).toLocaleDateString()}</div>
                    </div>
                    <div class="product-actions">
                        <button class="edit-btn" data-id="${product._id}">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="delete-btn" data-id="${product._id}">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                </div>
            `;
        });
        
        productsContainer.innerHTML = productsHTML;
        
        // Add event listeners to buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => editProduct(e.currentTarget.dataset.id));
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => showDeleteConfirmation(e.currentTarget.dataset.id));
        });
    }
    
    // Filter products based on search and filters
    function filterProducts() {
        const searchTerm = productSearch.value.toLowerCase();
        const category = categoryFilter.value;
        const status = statusFilter.value;
        
        return products.filter(product => {
            // Check if product name or description contains search term
            const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                                (product.description && product.description.toLowerCase().includes(searchTerm));
            
            // Check if product matches category filter
            const matchesCategory = category === '' || product.category === category;
            
            // Check if product matches status filter
            const matchesStatus = status === '' || product.status === status;
            
            return matchesSearch && matchesCategory && matchesStatus;
        });
    }
    
    // Open modal to add new product
    function openAddProductModal() {
        modalTitle.textContent = 'Add New Product';
        resetForm();
        productModal.style.display = 'block';
    }
    
    // Open modal to edit existing product
    async function editProduct(id) {
        try {
            const response = await fetch(`/api/products/${id}`);
            const product = await response.json();
            
            modalTitle.textContent = 'Edit Product';
            
            // Fill form with product data
            productIdInput.value = product._id;
            productNameInput.value = product.name;
            productDescInput.value = product.description || '';
            productCategoryInput.value = product.category;
            productQuantityInput.value = product.quantity;
            productPriceInput.value = product.price;
            
            // Format date for input field (YYYY-MM-DD)
            const expiryDate = new Date(product.expiryDate);
            const formattedDate = expiryDate.toISOString().split('T')[0];
            productExpiryInput.value = formattedDate;
            
            organicCheckInput.checked = product.isOrganic;
            
            // Display image preview if available
            if (product.image) {
                imagePreview.innerHTML = `<img src="${product.image}" alt="${product.name}">`;
            } else {
                imagePreview.innerHTML = '';
            }
            
            currentProductId = product._id;
            productModal.style.display = 'block';
        } catch (error) {
            showNotification('Error loading product details', 'error');
        }
    }
    
    // Show delete confirmation modal
    function showDeleteConfirmation(id) {
        currentProductId = id;
        confirmModal.style.display = 'block';
    }
    
    // Reset form fields
    function resetForm() {
        productForm.reset();
        productIdInput.value = '';
        imagePreview.innerHTML = '';
        currentProductId = null;
    }
    
    // Handle form submission (add/edit product)
    async function handleFormSubmit(e) {
        e.preventDefault();
        
        // Create FormData object for file upload
        const formData = new FormData();
        formData.append('name', productNameInput.value);
        formData.append('description', productDescInput.value);
        formData.append('category', productCategoryInput.value);
        formData.append('price', productPriceInput.value);
        formData.append('quantity', productQuantityInput.value);
        formData.append('expiryDate', productExpiryInput.value);
        formData.append('isOrganic', organicCheckInput.checked);
        
        // Only append image if a new one is selected
        if (productImageInput.files.length > 0) {
            formData.append('image', productImageInput.files[0]);
        }
        
        try {
            let url = '/api/products';
            let method = 'POST';
            
            // If editing an existing product
            if (currentProductId) {
                url = `/api/products/${currentProductId}`;
                method = 'PUT';
            }
            
            const response = await fetch(url, {
                method: method,
                body: formData
            });
            
            if (response.ok) {
                showNotification(
                    currentProductId ? 'Product updated successfully' : 'Product added successfully', 
                    'success'
                );
                productModal.style.display = 'none';
                await fetchProducts(); // Refresh the product list
            } else {
                const error = await response.json();
                throw new Error(error.message || 'Something went wrong');
            }
        } catch (error) {
            showNotification(error.message, 'error');
        }
    }
    
    // Delete a product
    async function deleteProduct() {
        try {
            const response = await fetch(`/api/products/${currentProductId}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                showNotification('Product deleted successfully', 'success');
                confirmModal.style.display = 'none';
                await fetchProducts(); // Refresh the product list
            } else {
                const error = await response.json();
                throw new Error(error.message || 'Something went wrong');
            }
        } catch (error) {
            showNotification(error.message, 'error');
        }
    }
    
    // Show notification message
    function showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                <div>
                    <div class="notification-message">${message}</div>
                </div>
            </div>
            <button class="close-notification">&times;</button>
        `;
        
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Hide after 5 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 5000);
        
        // Close button
        notification.querySelector('.close-notification').addEventListener('click', () => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        });
    }
    
    // Image preview functionality
    productImageInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Event listeners
    addProductBtn.addEventListener('click', openAddProductModal);
    closeBtn.addEventListener('click', () => productModal.style.display = 'none');
    cancelBtn.addEventListener('click', () => productModal.style.display = 'none');
    confirmDeleteBtn.addEventListener('click', deleteProduct);
    cancelDeleteBtn.addEventListener('click', () => confirmModal.style.display = 'none');
    productForm.addEventListener('submit', handleFormSubmit);
    
    // Search and filter event listeners
    productSearch.addEventListener('input', renderProducts);
    categoryFilter.addEventListener('change', renderProducts);
    statusFilter.addEventListener('change', renderProducts);
    
    // Close modals when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === productModal) {
            productModal.style.display = 'none';
        }
        if (e.target === confirmModal) {
            confirmModal.style.display = 'none';
        }
    });
    
    // Initial load
    fetchProducts();
});