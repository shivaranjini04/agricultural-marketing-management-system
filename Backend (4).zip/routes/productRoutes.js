const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const upload = require('../middleware/upload');

// @desc    Fetch all products for logged in user
// @route   GET /api/products
// @access  Private
router.get('/', async (req, res) => {
  try {
    // In a real app, you would get user ID from auth middleware
    // For now, we'll use a dummy user ID
    const userId = '647a1a8c3cd7f3b8e0c9b1a2'; // Replace with real user auth logic
    
    const products = await Product.find({ user: userId });
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @desc    Create a new product
// @route   POST /api/products
// @access  Private
router.post('/', upload.single('image'), async (req, res) => {
  try {
    // In a real app, you would get user ID from auth middleware
    const userId = '647a1a8c3cd7f3b8e0c9b1a2'; // Replace with real user auth logic
    
    const {
      name,
      description,
      category,
      price,
      quantity,
      expiryDate,
      isOrganic
    } = req.body;
    
    const product = new Product({
      name,
      description,
      category,
      price,
      quantity,
      expiryDate,
      isOrganic: isOrganic === 'true',
      user: userId,
      image: req.file ? `/uploads/${req.file.filename}` : '',
    });
    
    const createdProduct = await product.save();
    res.status(201).json(createdProduct);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private
router.put('/:id', upload.single('image'), async (req, res) => {
  try {
    const {
      name,
      description,
      category,
      price,
      quantity,
      expiryDate,
      isOrganic
    } = req.body;
    
    const product = await Product.findById(req.params.id);
    
    if (product) {
      product.name = name || product.name;
      product.description = description || product.description;
      product.category = category || product.category;
      product.price = price || product.price;
      product.quantity = quantity || product.quantity;
      product.expiryDate = expiryDate || product.expiryDate;
      product.isOrganic = isOrganic === 'true';
      
      if (req.file) {
        product.image = `/uploads/${req.file.filename}`;
      }
      
      const updatedProduct = await product.save();
      res.json(updatedProduct);
    } else {
      res.status(404).json({ message: 'Product not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// @desc    Delete a product
// @route   DELETE /api/products/:id
// @access  Private
router.delete('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (product) {
      await Product.deleteOne({ _id: product._id });
      res.json({ message: 'Product removed' });
    } else {
      res.status(404).json({ message: 'Product not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// @desc    Get product by ID
// @route   GET /api/products/:id
// @access  Private
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (product) {
      res.json(product);
    } else {
      res.status(404).json({ message: 'Product not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;