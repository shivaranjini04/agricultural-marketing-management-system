// products.js - Script to load products from MongoDB

document.addEventListener('DOMContentLoaded', async function() {
    // Initialize UI components
    initializeFilters();
    initializeModal();
    
    try {
        // Fetch products from the server
        await loadProductsFromMongoDB();
    } catch (error) {
        console.error('Error loading products:', error);
        showErrorMessage('Error loading products: ' + error.message);
    }
});

// Function to load products from MongoDB
async function loadProductsFromMongoDB() {
    try {
        console.log('Starting to fetch products...');
        
        // Get the products container - FIXED: using correct ID with hyphen
        const productsContainer = document.getElementById('products-container');
        
        if (!productsContainer) {
            console.error('Products container element not found! Make sure you have the correct ID in your HTML.');
            return;
        }
        
        // Show loading indicator
        productsContainer.innerHTML = '<div class="loading">Loading products...</div>';
        
        // Fetch products from the server
        const response = await fetch('http://localhost:5004/api/products');
        console.log('Response received:', response.status);
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to load products');
        }
        
        const products = await response.json();
        console.log('Products loaded:', products.length);
        
        // Clear any existing products
        productsContainer.innerHTML = '';
        
        // If no products found
        if (products.length === 0) {
            productsContainer.innerHTML = `
                <div class="no-products">
                    <i class="fas fa-box-open"></i>
                    <p>No products found. Add some products to see them here.</p>
                    <a href="addnewproduct.html" class="primary-btn">Add Product</a>
                </div>
            `;
            return;
        }
        
        // Render each product
        products.forEach(product => {
            const productCard = createProductCard(product);
            productsContainer.appendChild(productCard);
        });
        
        console.log('Products displayed successfully');
    } catch (error) {
        console.error('Error loading products:', error);
        showErrorMessage('Error loading products: ' + error.message);
    }
}

// Function to create a product card
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.setAttribute('data-id', product._id);
    
    // Format the date
    const expiryDate = product.expiryDate ? new Date(product.expiryDate).toLocaleDateString() : 'Not specified';
    
    // Default image if none provided
    const imageUrl = product.imageUrl || 'img/default-product.jpg';
    
    card.innerHTML = `
        <div class="product-image">
            <img src="${imageUrl}" alt="${product.productName}">
        </div>
        <div class="product-info">
            <h3>${product.productName}</h3>
            <p class="product-category">${product.category || 'Uncategorized'}</p>
            <div class="product-details">
                <p><strong>Price:</strong> $${product.price.toFixed(2)} / kg</p>
                <p><strong>Quantity:</strong> ${product.quantity} kg available</p>
                <p><strong>Expiry:</strong> ${expiryDate}</p>
            </div>
            <div class="product-actions">
                <button class="edit-btn" onclick="openEditModal('${product._id}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="delete-btn" onclick="openDeleteModal('${product._id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    `;
    
    return card;
}

// Function to show error message in the container
function showErrorMessage(message) {
    const productsContainer = document.getElementById('products-container');
    if (productsContainer) {
        productsContainer.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>${message}</p>
                <button onclick="loadProductsFromMongoDB()" class="secondary-btn">
                    <i class="fas fa-sync"></i> Try Again
                </button>
            </div>
        `;
    }
}

// Function to initialize filter functionality
function initializeFilters() {
    const searchInput = document.getElementById('product-search');
    const categoryFilter = document.getElementById('category-filter');
    const statusFilter = document.getElementById('status-filter');
    
    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', applyFilters);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', applyFilters);
    }
}

// Function to apply filters
function applyFilters() {
    // To be implemented based on your filtering requirements
    console.log('Filters applied');
}

// Function to initialize modal functionality
function initializeModal() {
    // Get modal elements
    const modal = document.getElementById('product-modal');
    const confirmModal = document.getElementById('confirm-modal');
    const closeBtn = document.querySelector('.close');
    const cancelBtn = document.getElementById('cancel-btn');
    const cancelDeleteBtn = document.getElementById('cancel-delete');
    const productForm = document.getElementById('product-form');
    
    // Close modal when clicking the close button
    if (closeBtn) {
        closeBtn.onclick = function() {
            modal.style.display = "none";
        }
    }
    
    // Close modal when clicking cancel button
    if (cancelBtn) {
        cancelBtn.onclick = function() {
            modal.style.display = "none";
        }
    }
    
    // Close confirmation modal when clicking cancel
    if (cancelDeleteBtn) {
        cancelDeleteBtn.onclick = function() {
            confirmModal.style.display = "none";
        }
    }
    
    // Close modals when clicking outside of them
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
        if (event.target == confirmModal) {
            confirmModal.style.display = "none";
        }
    }
    
    // Handle form submission
    if (productForm) {
        productForm.addEventListener('submit', handleFormSubmit);
    }
    
    // Initialize image preview functionality
    const imageInput = document.getElementById('product-image');
    if (imageInput) {
        imageInput.addEventListener('change', function(e) {
            const imagePreview = document.getElementById('image-preview');
            if (imagePreview) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        imagePreview.innerHTML = `<img src="${event.target.result}" alt="Product Preview">`;
                    }
                    reader.readAsDataURL(file);
                }
            }
        });
    }
}

// Function to open the edit modal
function openEditModal(productId) {
    // Fetch the product details and populate the form
    fetchProductDetails(productId).then(product => {
        if (product) {
            const modal = document.getElementById('product-modal');
            const modalTitle = document.getElementById('modal-title');
            
            if (modal && modalTitle) {
                // Set modal title and product ID
                modalTitle.textContent = 'Edit Product';
                document.getElementById('product-id').value = product._id;
                
                // Fill form fields with product data
                document.getElementById('product-name').value = product.productName;
                document.getElementById('product-description').value = product.description || '';
                document.getElementById('product-category').value = product.category || '';
                document.getElementById('product-quantity').value = product.quantity;
                document.getElementById('product-price').value = product.price;
                
                // Format date for input field (YYYY-MM-DD)
                if (product.expiryDate) {
                    const date = new Date(product.expiryDate);
                    const formattedDate = date.toISOString().split('T')[0];
                    document.getElementById('product-expiry').value = formattedDate;
                } else {
                    document.getElementById('product-expiry').value = '';
                }
                
                // Set organic checkbox
                document.getElementById('organic-check').checked = product.isOrganic || false;
                
                // Show product image if available
                const imagePreview = document.getElementById('image-preview');
                if (imagePreview) {
                    if (product.imageUrl) {
                        imagePreview.innerHTML = `<img src="${product.imageUrl}" alt="Product Preview">`;
                    } else {
                        imagePreview.innerHTML = '';
                    }
                }
                
                // Display the modal
                modal.style.display = "block";
            }
        }
    }).catch(error => {
        console.error('Error fetching product details:', error);
        alert('Error loading product details: ' + error.message);
    });
}

// Function to fetch product details by ID
async function fetchProductDetails(productId) {
    try {
        const response = await fetch(`http://localhost:5004/api/products/${productId}`);
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to fetch product details');
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Function to open the delete confirmation modal
function openDeleteModal(productId) {
    const confirmModal = document.getElementById('confirm-modal');
    const confirmDeleteBtn = document.getElementById('confirm-delete');
    
    if (confirmModal && confirmDeleteBtn) {
        // Set up delete confirmation
        confirmDeleteBtn.onclick = function() {
            deleteProduct(productId);
            confirmModal.style.display = "none";
        }
        
        // Display the modal
        confirmModal.style.display = "block";
    }
}

// Function to handle form submission
async function handleFormSubmit(event) {
    event.preventDefault();
    
    try {
        const productId = document.getElementById('product-id').value;
        const isEditMode = productId ? true : false;
        
        // Get form data
        const productData = {
            productName: document.getElementById('product-name').value,
            description: document.getElementById('product-description').value,
            category: document.getElementById('product-category').value,
            quantity: parseFloat(document.getElementById('product-quantity').value),
            price: parseFloat(document.getElementById('product-price').value),
            expiryDate: document.getElementById('product-expiry').value,
            isOrganic: document.getElementById('organic-check').checked
        };
        
        // Handle image upload
        const imageInput = document.getElementById('product-image');
        if (imageInput.files && imageInput.files[0]) {
            const reader = new FileReader();
            reader.onload = async function(e) {
                productData.imageUrl = e.target.result;
                await saveProduct(productData, isEditMode, productId);
            };
            reader.readAsDataURL(imageInput.files[0]);
        } else {
            // If editing and no new image selected, keep the existing image
            if (isEditMode) {
                const existingProduct = await fetchProductDetails(productId);
                productData.imageUrl = existingProduct.imageUrl;
            }
            await saveProduct(productData, isEditMode, productId);
        }
    } catch (error) {
        console.error('Error saving product:', error);
        alert('Error saving product: ' + error.message);
    }
}

// Function to save product (create or update)
async function saveProduct(productData, isEditMode, productId) {
    try {
        const url = isEditMode 
            ? `http://localhost:5004/api/products/${productId}`
            : 'http://localhost:5004/api/products';
        
        const method = isEditMode ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productData)
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to save product');
        }
        
        // Close the modal
        const modal = document.getElementById('product-modal');
        if (modal) {
            modal.style.display = "none";
        }
        
        // Refresh the products list
        await loadProductsFromMongoDB();
        
        alert(isEditMode ? 'Product updated successfully!' : 'Product added successfully!');
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Function to delete a product
async function deleteProduct(productId) {
    try {
        const response = await fetch(`http://localhost:5004/api/products/${productId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to delete product');
        }
        
        // Refresh the products list
        await loadProductsFromMongoDB();
        
        alert('Product deleted successfully!');
    } catch (error) {
        console.error('Error:', error);
        alert('Error deleting product: ' + error.message);
    }
}