// Initialize shopping cart
let cart = JSON.parse(localStorage.getItem('cart')) || [];
updateCartCount();

document.addEventListener('DOMContentLoaded', async function() {
    // Initialize UI components
    initializeSearch();
    initializeCart();
    
    // Set up view products button
    const viewProductsBtn = document.querySelector('.view-btn');
    if (viewProductsBtn) {
        viewProductsBtn.addEventListener('click', function() {
            const productsSection = document.querySelector('.products-section');
            productsSection.scrollIntoView({ behavior: 'smooth' });
        });
    }
    
    try {
        // Fetch products from the server
        await loadProductsForBuyer();
    } catch (error) {
        console.error('Error loading products:', error);
        showErrorMessage('Error loading products: ' + error.message);
    }
});

// Function to load products from MongoDB for buyer
async function loadProductsForBuyer() {
    try {
        console.log('Starting to fetch products for buyer...');
        
        // Get the products container or create one if it doesn't exist
        let productsContainer = document.getElementById('products-container');
        if (!productsContainer) {
            productsContainer = document.createElement('div');
            productsContainer.id = 'products-container';
            productsContainer.className = 'products-grid';
            
            // Append it to the products section
            const productsSection = document.querySelector('.products-section');
            if (productsSection) {
                productsSection.appendChild(productsContainer);
            } else {
                console.error('Products section not found!');
                return;
            }
        }
        
        // Show loading indicator
        productsContainer.innerHTML = '<div class="loading">Loading products...</div>';
        
        // Fetch products from the server with error handling
        try {
            const response = await fetch('http://localhost:5002/api/products');
            console.log('Response received:', response.status);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to load products');
            }
            
            const products = await response.json();
            console.log('Products loaded:', products.length);
            
            // Clear any existing products
            productsContainer.innerHTML = '';
            
            // If no products found
            if (products.length === 0) {
                productsContainer.innerHTML = `
                    <div class="no-products">
                        <i class="fas fa-box-open"></i>
                        <p>No products available at the moment. Please check back later.</p>
                    </div>
                `;
                return;
            }
            
            // Render each product
            products.forEach(product => {
                const productCard = createBuyerProductCard(product);
                productsContainer.appendChild(productCard);
            });
            
            console.log('Products displayed successfully for buyer');
        } catch (fetchError) {
            console.error('Fetch error:', fetchError);
            productsContainer.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Failed to connect to the server. Please check your connection and try again.</p>
                    <button onclick="loadProductsForBuyer()" class="secondary-btn">
                        <i class="fas fa-sync"></i> Try Again
                    </button>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading products:', error);
        showErrorMessage('Error loading products: ' + error.message);
    }
}

// Function to create a product card for buyer
function createBuyerProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.setAttribute('data-id', product._id);
    card.setAttribute('data-name', product.productName.toLowerCase());
    card.setAttribute('data-category', (product.category || 'uncategorized').toLowerCase());
    
    // Format the date
    const expiryDate = product.expiryDate ? new Date(product.expiryDate).toLocaleDateString() : 'Not specified';
    
    // Default image if none provided
    const imageUrl = product.imageUrl || 'img/default-product.jpg';
    
    // Check if product is in stock
    const inStock = product.quantity > 0;
    
    card.innerHTML = `
        <div class="product-image">
            <img src="${imageUrl}" alt="${product.productName}" 
                 onerror="this.src='img/default-product.jpg';" 
                 loading="lazy"
                 style="max-width: 150px; max-height: 150px; object-fit: contain;">
            ${product.isOrganic ? '<span class="organic-badge">Organic</span>' : ''}
        </div>
        <div class="product-info">
            <h3>${product.productName}</h3>
            <p class="product-category">${product.category || 'Uncategorized'}</p>
            <div class="product-details">
                <p class="product-price">$${product.price.toFixed(2)} / kg</p>
                <p class="product-stock ${inStock ? 'in-stock' : 'out-of-stock'}">
                    ${inStock ? `${product.quantity} kg available` : 'Out of stock'}
                </p>
                <p class="product-expiry">Expiry: ${expiryDate}</p>
            </div>
            <div class="product-actions">
                <div class="quantity-controls">
                    <button class="quantity-btn minus" ${!inStock ? 'disabled' : ''}>-</button>
                    <input type="number" class="quantity-input" value="1" min="1" max="${product.quantity}" ${!inStock ? 'disabled' : ''}>
                    <button class="quantity-btn plus" ${!inStock ? 'disabled' : ''}>+</button>
                </div>
                <button class="add-to-cart-btn" ${!inStock ? 'disabled' : ''} data-id="${product._id}">
                    <i class="fas fa-cart-plus"></i> Add to Cart
                </button>
                <button class="buy-now-btn" ${!inStock ? 'disabled' : ''} data-id="${product._id}">
                    <i class="fas fa-shopping-bag"></i> Buy Now
                </button>
            </div>
        </div>
    `;
    
    // Add event listeners
    const minusBtn = card.querySelector('.minus');
    const plusBtn = card.querySelector('.plus');
    const quantityInput = card.querySelector('.quantity-input');
    const addToCartBtn = card.querySelector('.add-to-cart-btn');
    const buyNowBtn = card.querySelector('.buy-now-btn');
    
    if (minusBtn && plusBtn && quantityInput) {
        minusBtn.addEventListener('click', () => {
            const currentValue = parseInt(quantityInput.value);
            if (currentValue > 1) {
                quantityInput.value = currentValue - 1;
            }
        });
        
        plusBtn.addEventListener('click', () => {
            const currentValue = parseInt(quantityInput.value);
            const maxValue = parseInt(quantityInput.getAttribute('max'));
            if (currentValue < maxValue) {
                quantityInput.value = currentValue + 1;
            }
        });
        
        quantityInput.addEventListener('change', () => {
            let value = parseInt(quantityInput.value);
            const maxValue = parseInt(quantityInput.getAttribute('max'));
            
            if (isNaN(value) || value < 1) {
                value = 1;
            } else if (value > maxValue) {
                value = maxValue;
            }
            
            quantityInput.value = value;
        });
    }
    
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', () => {
            const quantity = parseInt(quantityInput.value);
            addToCart(product, quantity);
        });
    }
    
    if (buyNowBtn) {
        buyNowBtn.addEventListener('click', () => {
            const quantity = parseInt(quantityInput.value);
            openBuyerModal(product, quantity);
        });
    }
    
    return card;
}

// Function to add a product to cart
function addToCart(product, quantity) {
    // Validate quantity
    if (!quantity || isNaN(quantity) || quantity <= 0) {
        showNotification('Please select a valid quantity', 'error');
        return;
    }
    
    // Check if we exceed available stock
    if (quantity > product.quantity) {
        showNotification(`Only ${product.quantity} kg available`, 'error');
        return;
    }
    
    // Check if product already in cart
    const existingItemIndex = cart.findIndex(item => item.productId === product._id);
    
    if (existingItemIndex !== -1) {
        // Update quantity if product already in cart
        const newQuantity = cart[existingItemIndex].quantity + quantity;
        
        // Check combined quantity against available stock
        if (newQuantity > product.quantity) {
            showNotification(`Cannot add more. You already have ${cart[existingItemIndex].quantity} kg in cart`, 'error');
            return;
        }
        
        cart[existingItemIndex].quantity = newQuantity;
    } else {
        // Add new item to cart
        cart.push({
            productId: product._id,
            name: product.productName,
            price: product.price,
            image: product.imageUrl || 'img/default-product.jpg',
            quantity: quantity,
            maxQuantity: product.quantity // Store max available quantity for validation
        });
    }
    
    // Save cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count
    updateCartCount();
    
    // Show confirmation
    showNotification(`Added ${quantity} kg of ${product.productName} to cart`);
}

// Function to update cart count
function updateCartCount() {
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartCount.textContent = totalItems;
        
        // Add animation class
        cartCount.classList.add('cart-count-update');
        
        // Remove animation class after animation completes
        setTimeout(() => {
            cartCount.classList.remove('cart-count-update');
        }, 300);
    }
}

// Function to initialize search functionality
function initializeSearch() {
    const searchBtn = document.querySelector('.search-btn');
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            // Create search bar if it doesn't exist
            let searchBar = document.querySelector('.search-bar');
            
            if (!searchBar) {
                searchBar = document.createElement('div');
                searchBar.className = 'search-bar';
                searchBar.innerHTML = `
                    <input type="text" id="product-search" placeholder="Search products...">
                    <button class="clear-search" style="display: none;"><i class="fas fa-times-circle"></i></button>
                    <button class="close-search"><i class="fas fa-times"></i></button>
                `;
                
                const header = document.querySelector('header');
                header.appendChild(searchBar);
                
                // Add event listener for search input with debounce
                const searchInput = searchBar.querySelector('#product-search');
                const clearSearchBtn = searchBar.querySelector('.clear-search');
                
                // Debounce function to limit how often filterProducts is called
                let debounceTimer;
                searchInput.addEventListener('input', function() {
                    clearTimeout(debounceTimer);
                    
                    // Show/hide clear button based on input content
                    if (this.value.length > 0) {
                        clearSearchBtn.style.display = 'block';
                    } else {
                        clearSearchBtn.style.display = 'none';
                    }
                    
                    debounceTimer = setTimeout(() => {
                        filterProducts(this.value);
                    }, 300);
                });
                
                // Add event listener for clear button
                clearSearchBtn.addEventListener('click', function() {
                    searchInput.value = '';
                    this.style.display = 'none';
                    filterProducts('');
                    searchInput.focus();
                });
                
                // Add event listener for close button
                const closeBtn = searchBar.querySelector('.close-search');
                closeBtn.addEventListener('click', function() {
                    searchBar.remove();
                    // Reset filter
                    filterProducts('');
                });
                
                // Focus on the search input
                searchInput.focus();
            }
        });
    }
}

// Function to filter products
function filterProducts(query) {
    const productCards = document.querySelectorAll('.product-card');
    const lowerCaseQuery = query.toLowerCase().trim();
    
    if (!lowerCaseQuery) {
        // If no query, show all products
        productCards.forEach(card => {
            card.style.display = '';
        });
        return;
    }
    
    // Use dataset attributes for faster filtering
    productCards.forEach(card => {
        const productName = card.getAttribute('data-name');
        const productCategory = card.getAttribute('data-category');
        
        if (productName.includes(lowerCaseQuery) || productCategory.includes(lowerCaseQuery)) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
    
    // Check if no visible products after filtering
    const visibleProducts = document.querySelectorAll('.product-card[style=""]');
    const container = document.getElementById('products-container');
    
    if (visibleProducts.length === 0 && container) {
        // No products match the search query
        const noResultsEl = document.createElement('div');
        noResultsEl.className = 'no-search-results';
        noResultsEl.innerHTML = `
            <i class="fas fa-search"></i>
            <p>No products match "${query}"</p>
        `;
        
        // Remove any existing no-results message
        const existingNoResults = container.querySelector('.no-search-results');
        if (existingNoResults) {
            container.removeChild(existingNoResults);
        }
        
        container.appendChild(noResultsEl);
    } else {
        // Remove no-results message if it exists
        const existingNoResults = container.querySelector('.no-search-results');
        if (existingNoResults) {
            container.removeChild(existingNoResults);
        }
    }
}

// Function to initialize cart functionality
function initializeCart() {
    const cartBtn = document.querySelector('.cart-btn');
    
    if (cartBtn) {
        cartBtn.addEventListener('click', function(e) {
            e.preventDefault();
            openCartModal();
        });
    }
}

// Function to open cart modal
function openCartModal() {
    // Create cart modal if it doesn't exist
    let cartModal = document.getElementById('cart-modal');
    
    if (!cartModal) {
        cartModal = document.createElement('div');
        cartModal.id = 'cart-modal';
        cartModal.className = 'modal';
        
        document.body.appendChild(cartModal);
    }
    
    // Update cart modal content
    updateCartModal();
    
    // Show the modal with fade-in effect
    cartModal.style.display = 'block';
    setTimeout(() => {
        cartModal.classList.add('show');
    }, 10);
}

// Function to update cart modal content
function updateCartModal() {
    const cartModal = document.getElementById('cart-modal');
    
    if (cartModal) {
        // Calculate cart total
        const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
        
        // Create fragment for better performance
        const fragment = document.createDocumentFragment();
        const modalContent = document.createElement('div');
        modalContent.className = 'modal-content';
        
        modalContent.innerHTML = `
            <div class="modal-header">
                <h2>Shopping Cart ${cart.length > 0 ? `(${cart.length} items)` : ''}</h2>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body">
                ${cart.length === 0 ? 
                    `<div class="empty-cart">
                        <i class="fas fa-shopping-cart"></i>
                        <p>Your cart is empty</p>
                        <button class="secondary-btn" id="start-shopping-btn">
                            Start Shopping
                        </button>
                    </div>` : 
                    `<div class="cart-items">
                        ${cart.map(item => `
                            <div class="cart-item" data-id="${item.productId}">
                                <div class="cart-item-image">
                                    <img src="${item.image}" alt="${item.name}" 
                                         onerror="this.src='img/default-product.jpg';" 
                                         style="max-width: 80px; max-height: 80px; object-fit: contain;">
                                </div>
                                <div class="cart-item-details">
                                    <h4>${item.name}</h4>
                                    <p>$${item.price.toFixed(2)} / kg</p>
                                    <div class="cart-quantity">
                                        <button class="cart-quantity-btn cart-minus" data-id="${item.productId}">-</button>
                                        <span>${item.quantity}</span>
                                        <button class="cart-quantity-btn cart-plus" data-id="${item.productId}" 
                                                ${item.quantity >= (item.maxQuantity || Infinity) ? 'disabled' : ''}>+</button>
                                    </div>
                                </div>
                                <div class="cart-item-price">
                                    $${(item.price * item.quantity).toFixed(2)}
                                </div>
                                <button class="remove-item-btn" data-id="${item.productId}" aria-label="Remove item">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        `).join('')}
                    </div>
                    <div class="cart-total">
                        <h3>Total: $${cartTotal.toFixed(2)}</h3>
                    </div>`
                }
            </div>
            <div class="modal-footer">
                <button class="secondary-btn" id="clear-cart-btn" ${cart.length === 0 ? 'disabled' : ''}>
                    Clear Cart
                </button>
                <button class="primary-btn" id="checkout-btn" ${cart.length === 0 ? 'disabled' : ''}>
                    Proceed to Checkout
                </button>
            </div>
        `;
        
        fragment.appendChild(modalContent);
        
        // Clear existing content and append new content
        cartModal.innerHTML = '';
        cartModal.appendChild(fragment);
        
        // Add event listeners
        // Close button
        const closeBtn = cartModal.querySelector('.close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                closeCartModal();
            });
        }
        
        // Start shopping button for empty cart
        const startShoppingBtn = cartModal.querySelector('#start-shopping-btn');
        if (startShoppingBtn) {
            startShoppingBtn.addEventListener('click', function() {
                closeCartModal();
                
                // Scroll to products section
                const productsSection = document.querySelector('.products-section');
                if (productsSection) {
                    productsSection.scrollIntoView({ behavior: 'smooth' });
                }
            });
        }
        
        // Quantity buttons
        const minusBtns = cartModal.querySelectorAll('.cart-minus');
        const plusBtns = cartModal.querySelectorAll('.cart-plus');
        
        minusBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                updateCartItemQuantity(productId, -1);
            });
        });
        
        plusBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                updateCartItemQuantity(productId, 1);
            });
        });
        
        // Remove item buttons
        const removeItemBtns = cartModal.querySelectorAll('.remove-item-btn');
        removeItemBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                removeFromCart(productId);
            });
        });
        
        // Clear cart button
        const clearCartBtn = document.getElementById('clear-cart-btn');
        if (clearCartBtn) {
            clearCartBtn.addEventListener('click', function() {
                if (confirm('Are you sure you want to clear your cart?')) {
                    clearCart();
                }
            });
        }
        
        // Checkout button
        const checkoutBtn = document.getElementById('checkout-btn');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', function() {
                proceedToCheckout();
            });
        }
        
        // Close when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === cartModal) {
                closeCartModal();
            }
        });
    }
}

// Function to close cart modal
function closeCartModal() {
    const cartModal = document.getElementById('cart-modal');
    if (cartModal) {
        cartModal.classList.remove('show');
        setTimeout(() => {
            cartModal.style.display = 'none';
        }, 300);
    }
}

// Function to update cart item quantity
function updateCartItemQuantity(productId, change) {
    const itemIndex = cart.findIndex(item => item.productId === productId);
    
    if (itemIndex !== -1) {
        const newQuantity = cart[itemIndex].quantity + change;
        const maxQuantity = cart[itemIndex].maxQuantity;
        
        if (newQuantity <= 0) {
            // Remove item if quantity is 0 or less
            removeFromCart(productId);
        } else if (maxQuantity && newQuantity > maxQuantity) {
            // Check if we exceed maximum quantity
            showNotification(`Only ${maxQuantity} kg available`, 'error');
        } else {
            // Update quantity
            cart[itemIndex].quantity = newQuantity;
            
            // Save cart to localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
            
            // Update cart UI
            updateCartCount();
            updateCartModal();
        }
    }
}

// Function to remove item from cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.productId !== productId);
    
    // Save cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart UI
    updateCartCount();
    updateCartModal();
}

// Function to clear cart
function clearCart() {
    cart = [];
    
    // Save cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart UI
    updateCartCount();
    updateCartModal();
}

// Function to proceed to checkout
function proceedToCheckout() {
    // Create checkout modal
    let checkoutModal = document.getElementById('checkout-modal');
    
    if (!checkoutModal) {
        checkoutModal = document.createElement('div');
        checkoutModal.id = 'checkout-modal';
        checkoutModal.className = 'modal';
        
        document.body.appendChild(checkoutModal);
    }
    
    // Calculate cart total
    const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);

    // After updating the modal content, wait a moment before attaching event listeners
    setTimeout(() => {
        // Payment method toggle
        const paymentCard = document.getElementById('payment-card');
        const paymentCash = document.getElementById('payment-cash');
        const cardDetails = document.getElementById('card-details');
        
        if (paymentCard && paymentCash && cardDetails) {
            paymentCard.addEventListener('change', function() {
                if (this.checked) {
                    cardDetails.style.display = 'block';
                }
            });
            
            paymentCash.addEventListener('change', function() {
                if (this.checked) {
                    cardDetails.style.display = 'none';
                }
            });
        }
        
        // Back to cart button
        const backToCartBtn = document.getElementById('back-to-cart-btn');
        if (backToCartBtn) {
            backToCartBtn.addEventListener('click', function() {
                checkoutModal.style.display = 'none';
                
                // Re-open the cart modal
                openCartModal();
            });
        }
        
        // Place order button
        const placeOrderBtn = document.getElementById('place-order-btn');
        if (placeOrderBtn) {
            placeOrderBtn.addEventListener('click', function() {
                // Validate form
                const nameInput = document.getElementById('fullname');
                const addressInput = document.getElementById('address');
                const phoneInput = document.getElementById('phone');
                const emailInput = document.getElementById('email');
                
                if (!nameInput.value || !addressInput.value || !phoneInput.value || !emailInput.value) {
                    // Show error for required fields
                    showNotification('Please fill in all required fields', 'error');
                    return;
                }
                
                // Check if card payment is selected and validate card details
                const paymentCard = document.getElementById('payment-card');
                
                if (paymentCard.checked) {
                    const cardNumber = document.getElementById('card-number');
                    const expiryDate = document.getElementById('expiry-date');
                    const cvv = document.getElementById('cvv');
                    
                    if (!cardNumber.value || !expiryDate.value || !cvv.value) {
                        // Show error for card details
                        showNotification('Please fill in all card details', 'error');
                        return;
                    }
                }
                
                // If validation passes, place the order
                placeOrder();
            });
        }
    }, 100); // Small delay to ensure DOM elements are ready
    
    // Close the cart modal
    const cartModal = document.getElementById('cart-modal');
    if (cartModal) {
        cartModal.style.display = 'none';
    }
    
    // Show the checkout modal
    checkoutModal.style.display = 'block';
    
    // Add event listeners
    // Close button
    const closeBtn = checkoutModal.querySelector('.close');
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            checkoutModal.style.display = 'none';
        });
    }
    
    // Payment method toggle
    const paymentCard = document.getElementById('payment-card');
    const paymentCash = document.getElementById('payment-cash');
    const cardDetails = document.getElementById('card-details');
    
    if (paymentCard && paymentCash && cardDetails) {
        paymentCard.addEventListener('change', function() {
            if (this.checked) {
                cardDetails.style.display = 'block';
            }
        });
        
        paymentCash.addEventListener('change', function() {
            if (this.checked) {
                cardDetails.style.display = 'none';
            }
        });
    }
    
    // Back to cart button
    const backToCartBtn = document.getElementById('back-to-cart-btn');
    if (backToCartBtn) {
        backToCartBtn.addEventListener('click', function() {
            checkoutModal.style.display = 'none';
            
            // Re-open the cart modal
            openCartModal();
        });
    }
    
    // Place order button
    const placeOrderBtn = document.getElementById('place-order-btn');
    if (placeOrderBtn) {
        placeOrderBtn.addEventListener('click', function() {
            // Validate form
            const deliveryForm = document.getElementById('delivery-form');
            
            // Get required fields
            const nameInput = document.getElementById('fullname');
            const addressInput = document.getElementById('address');
            const phoneInput = document.getElementById('phone');
            const emailInput = document.getElementById('email');
            
            if (!nameInput.value || !addressInput.value || !phoneInput.value || !emailInput.value) {
                // Show error for required fields
                showNotification('Please fill in all required fields', 'error');
                return;
            }
            
            // Check if card payment is selected and validate card details
            const paymentCard = document.getElementById('payment-card');
            
            if (paymentCard.checked) {
                const cardNumber = document.getElementById('card-number');
                const expiryDate = document.getElementById('expiry-date');
                const cvv = document.getElementById('cvv');
                
                if (!cardNumber.value || !expiryDate.value || !cvv.value) {
                    // Show error for card details
                    showNotification('Please fill in all card details', 'error');
                    return;
                }
            }
            
            // If validation passes, place the order
            placeOrder();
        });
    }
    
    // Close when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === checkoutModal) {
            checkoutModal.style.display = 'none';
        }
    });
}

// Function to place an order
async function placeOrder() {
    try {
        // Show loading indicator
        showNotification('Processing your order...', 'info');
        
        // Get form values
        const name = document.getElementById('fullname').value;
        const address = document.getElementById('address').value;
        const phone = document.getElementById('phone').value;
        const email = document.getElementById('email').value;
        const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
        
        // Get cart items
        const items = cart.map(item => ({
            productId: item.productId,
            name: item.name,
            price: item.price,
            quantity: item.quantity,
            subtotal: item.price * item.quantity
        }));
        
        // Calculate total
        const total = items.reduce((sum, item) => sum + item.subtotal, 0);
        
        // Create order object
        const order = {
            customer: {
                name,
                address,
                phone,
                email
            },
            items,
            total,
            paymentMethod,
            status: 'pending',
            orderDate: new Date()
        };
        
        // Log the order object for debugging
        console.log('Order:', order);
        
        // Send order to server
        const response = await fetch('http://localhost:5001/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(order)
        });
        
        // Log the response for debugging
        console.log('Response:', response);
        
        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error:', errorData); // Log the error
            throw new Error(errorData.message || 'Failed to place order');
        }
        
        const orderResult = await response.json();
        console.log('Order Result:', orderResult); // Log the result
        
        // Close checkout modal
        const checkoutModal = document.getElementById('checkout-modal');
        if (checkoutModal) {
            checkoutModal.style.display = 'none';
        }
        
        // Clear the cart
        clearCart();
        
        // Show order confirmation
        showOrderConfirmation(orderResult);
        
    } catch (error) {
        console.error('Error placing order:', error);
        showNotification('Error placing order: ' + error.message, 'error');
    }
}