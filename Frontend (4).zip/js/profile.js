document.addEventListener('DOMContentLoaded', function () {
    // Load profile data from localStorage or use default data
    const profileData = JSON.parse(localStorage.getItem('profileData')) || {
        fullName: "John Doe",
        phoneNumber: "+1234567890",
        email: "john.doe@example.com",
        location: "New York, USA",
        farmName: "Green Valley Farm",
        farmSize: "10 acres",
        farmingType: "Organic Farming",
        experience: "5 years",
        aboutMe: "I am a passionate farmer with over 5 years of experience in organic farming.",
        specializations: ["Organic Vegetables", "Fruit Orchards", "Sustainable Farming"],
        profileImage: "img/default-profile.jpg", // Default profile image
        productsCount: 0,
        salesCount: 0,
        memberSince: 0
    };

    // Populate profile data in the UI
    document.getElementById('farmer-name').textContent = profileData.fullName;
    document.getElementById('farmer-phone').textContent = profileData.phoneNumber;
    document.getElementById('farmer-email').textContent = profileData.email;
    document.getElementById('farmer-location').textContent = profileData.location;
    document.getElementById('farm-name').textContent = profileData.farmName;
    document.getElementById('farm-size').textContent = profileData.farmSize;
    document.getElementById('farming-type').textContent = profileData.farmingType;
    document.getElementById('experience-years').textContent = profileData.experience;
    document.getElementById('farmer-about').textContent = profileData.aboutMe;

    // Populate specializations
    const specializationsContainer = document.getElementById('farmer-specializations');
    profileData.specializations.forEach(specialization => {
        const tag = document.createElement('div');
        tag.className = 'specialization-tag';
        tag.textContent = specialization;
        specializationsContainer.appendChild(tag);
    });

    // Populate profile image
    const profileImagePreview = document.getElementById('profile-image-preview');
    profileImagePreview.src = profileData.profileImage;

    // Populate stats (Products, Sales, Members)
    updateStatsUI(profileData);

    // Handle profile image upload
    const profileImageInput = document.getElementById('profile-image-input');
    const photoEditOverlay = document.getElementById('photo-edit-overlay');

    photoEditOverlay.addEventListener('click', function () {
        profileImageInput.click(); // Trigger file input
    });

    profileImageInput.addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (event) {
                // Update profile image preview
                profileImagePreview.src = event.target.result;

                // Save the new image to localStorage
                profileData.profileImage = event.target.result;
                localStorage.setItem('profileData', JSON.stringify(profileData));

                showNotification('Profile picture updated successfully!', 'success');
            };
            reader.readAsDataURL(file);
        }
    });

    // Function to update stats in the UI
    function updateStatsUI(data) {
        document.getElementById('products-count').textContent = data.productsCount;
        document.getElementById('sales-count').textContent = data.salesCount;
        document.getElementById('member-since').textContent = data.memberSince;
    }

    // Function to update stats dynamically
    function updateStats(newStats) {
        // Update the profileData object
        profileData.productsCount = newStats.productsCount || profileData.productsCount;
        profileData.salesCount = newStats.salesCount || profileData.salesCount;
        profileData.memberSince = newStats.memberSince || profileData.memberSince;

        // Save updated data to localStorage
        localStorage.setItem('profileData', JSON.stringify(profileData));

        // Update the UI
        updateStatsUI(profileData);

        showNotification('Stats updated successfully!', 'success');
    }

    // Example: Update stats dynamically (can be triggered by user actions or backend API)
    setTimeout(() => {
        updateStats({
            productsCount: 10,
            salesCount: 5,
            memberSince: 2
        });
    }, 3000); // Simulate a delay (e.g., API call)

    // Function to show notifications (optional)
    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
});